
# FullStack Rating App

This is a full stack application with:

- Backend: Express.js with JWT authentication
- Frontend: React with Vite
- Database: PostgreSQL

## Features
- User registration and login
- Role-based access: Admin, Store Owner, Normal User
- Store listing and ratings
- Admin dashboard for stats
- Store Owner dashboard for feedback
